let speech = new SpeechSynthesisUtterance();

let voices =[];

let voiceSelect = document.querySelector("select");

window.speechSynthesis.onvoiceschanged = () => {
    voices = window.speechSynthesis.getVoices();
    speech.voice = voices[0];

    voices.forEach((voice, i) => (voiceSelect.options[i] = new Option(voice.name, i)));
};

voiceSelect.addEventListener("change", () => {
    speech.voice = voices[voiceSelect.value];
});

click_to_send.addEventListener("click",() =>{
    setTimeout(function() {
    // Get all elements with class name "bubble"
    var bubble = document.querySelectorAll(".msg-bubble");

    // Get the last bubble element
    var lastBubble = bubble[bubble.length - 1];

    var msgtext = lastBubble.querySelector('.msg-text');

    // Get the text content of the last bubble element
    var lastText = msgtext.textContent;

    // Assign the text content to speech.text
    speech.text = lastText;

    // Speak the text using speech synthesis
    window.speechSynthesis.speak(speech);
    }, 3000)

});

click_to_convert.addEventListener('click',function(){
    var voiceOn= true;
    window.SpeechRecognition= window.webkitSpeechRecognition;  
    const recognition= new SpeechRecognition();
    recognition.interimResults = true;
    
    recognition.addEventListener('result', e=>{
      const transcript = Array.from(e.results)
      .map(result =>result[0])
      .map(result => result.transcript)

      var inputElement = document.getElementById('textInput');
      inputElement.value = transcript
    })
    if(voiceOn==true){
      recognition.start();
    }
  })